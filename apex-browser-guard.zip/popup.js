"use strict";

const BUY_URL = "https://tinyradr.com/guard";
const $ = (id) => document.getElementById(id);

function el(tag, text, cls) {
  const n = document.createElement(tag);
  if (text != null) n.textContent = text;
  if (cls) n.className = cls;
  return n;
}

function render(st) {
  if (!st) return;
  const ad = $("ads");
  if (ad) {
    ad.checked = st.adShield !== false;
    ad.disabled = !st.protecting;
  }
  if (st.error) {
    $("mode").textContent = st.error;
    return;
  }
  $("mode").textContent = st.ruleError
    ? "rule error"
    : st.active
      ? st.unlocked
        ? "privacy filtering on"
        : `privacy trial · ${st.trialLeft}d left`
      : "privacy filtering off";
  $("toggle").checked = st.active;
  $("toggle").disabled = !st.protecting;

  const sites = Object.entries(st.log || {});
  let trk = 0,
    seen = 0;
  const box = $("box");
  box.replaceChildren();
  sites.sort((a, b) => b[1].trackers - a[1].trackers);
  for (const [site, row] of sites.slice(0, 25)) {
    const fields = Object.entries(row.seen);
    const count = fields.reduce((n, [, v]) => n + v, 0);
    trk += row.trackers;
    seen += count;
    if (!count && !row.trackers) continue;
    const d = el("div", null, "site");
    d.append(el("b", site));
    d.append(el("div", `${row.trackers} trackers · ${count} extra fields`, "muted"));
    if (fields.length)
      d.append(
        el("div", fields.map(([k, v]) => `${k} ×${v}`).join(", "), st.active ? "muted" : "warn"),
      );
    box.append(d);
  }
  if (!box.childElementCount)
    box.append(el("div", "Nothing observed yet. Browse a few sites.", "muted"));
  $("trk").textContent = trk;
  $("seen").textContent = seen;

  $("incog").textContent = st.incognitoAllowed
    ? "Opens in an incognito window."
    : "Tip: chrome://extensions → Apex Browser Guard → Details → Allow in Incognito, so searches open privately.";

  $("lan").checked = Boolean(st.lanShield);
  $("links").checked = st.linkScrub !== false;
  $("ver").textContent = st.version ? `v${st.version}` : "";
  const news = $("news");
  news.replaceChildren();
  const fresh = (GuardPolicy.CHANGELOG || []).slice(0, 2);
  news.append(
    el(
      "b",
      `${fresh.length} upgrades in this version line — included free for every install${st.previousVersion ? ` (updated from v${st.previousVersion})` : ""}`,
    ),
  );
  for (const c of fresh) {
    const u = el("ul");
    u.prepend(el("div", `v${c.v}`, "muted"));
    for (const i of c.items) u.append(el("li", i));
    news.append(u);
  }
  const tl = $("tlist");
  tl.replaceChildren();
  for (const h of st.trustedHosts || []) {
    const row = el("div", null, "dom");
    row.append(el("span", h));
    const b = el("button", "Remove");
    b.addEventListener("click", () =>
      chrome.runtime.sendMessage({ type: "TRUSTED", host: h, remove: true }, refresh),
    );
    row.append(b);
    tl.append(row);
  }
  if (!tl.childElementCount)
    tl.append(
      el("div", "None. Everything on your home network is blocked from websites.", "muted"),
    );
  $("dom").checked = Boolean(st.domGuard);
  $("rules").textContent = st.ruleError
    ? `Rule installation failed: ${st.ruleError}`
    : st.ruleStatus === "configured-literal-hosts"
      ? `Rules configured · literal LAN filter ${st.enabled && st.lanShield ? "on" : "off"}; DNS rebinding not covered.`
      : "Rule status pending";

  // Unknown-domain panel: third-party hosts seen on the current tab's site.
  const doms = $("doms");
  doms.replaceChildren();
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    let host = "";
    try {
      host = new URL(tabs[0]?.url || "").hostname.replace(/^www\./, "");
    } catch {
      /* ignore */
    }
    const seen = Object.entries((st.hosts || {})[host] || {}).sort((a, b) => b[1] - a[1]);
    const blocked = new Set(st.blockedDomains || []);
    if (!seen.length) {
      doms.append(el("div", "No third-party domains seen here yet.", "muted"));
      return;
    }
    for (const [d, n] of seen.slice(0, 30)) {
      const row = el("div", null, "dom");
      row.append(el("span", `${d} ×${n}`));
      const b = el(
        "button",
        blocked.has(d) ? "Blocked" : "Block",
        blocked.has(d) ? "blocked" : null,
      );
      b.addEventListener("click", () =>
        chrome.runtime.sendMessage(
          { type: "DOMAIN_BLOCK", domain: d, remove: blocked.has(d) },
          refresh,
        ),
      );
      row.append(b);
      doms.append(row);
    }
  });

  const up = $("upsell");
  up.replaceChildren();
  if (st.unlocked) {
    up.append(el("h2", "Lifetime · activated on this device", null));
    up.append(el("p", "Verified locally. Every future Guard module is included.", "muted"));
  } else {
    up.append(
      el(
        "h2",
        st.trialLeft > 0
          ? "Get Lifetime — $19.99 launch (reg. $49.99)"
          : "Trial ended — get Lifetime",
        null,
      ),
    );
    const b = el("button", "Get Lifetime · unlocks automatically");
    b.addEventListener("click", () => chrome.tabs.create({ url: BUY_URL }));
    up.append(b);
  }
  const s = el("button", "Full observation · Apex Shield", "ghost");
  s.addEventListener("click", () =>
    chrome.tabs.create({ url: "https://apexsignalshield.com/shield" }),
  );
  up.append(s);
}

function refresh() {
  chrome.runtime.sendMessage({ type: "STATE" }, render);
}

$("toggle").addEventListener("change", (e) =>
  chrome.runtime.sendMessage({ type: "TOGGLE", on: e.target.checked }, refresh),
);
$("lan").addEventListener("change", (e) =>
  chrome.runtime.sendMessage({ type: "LAN_TOGGLE", on: e.target.checked }, refresh),
);
$("dom").addEventListener("change", (e) =>
  chrome.runtime.sendMessage({ type: "DOM_TOGGLE", on: e.target.checked }, refresh),
);
$("clear").addEventListener("click", () => chrome.runtime.sendMessage({ type: "CLEAR" }, refresh));
$("sf").addEventListener("submit", (e) => {
  e.preventDefault();
  const q = $("q").value.trim();
  if (q) chrome.runtime.sendMessage({ type: "SEARCH", q }, () => window.close());
});
$("links").addEventListener("change", (e) =>
  chrome.runtime.sendMessage({ type: "LINK_TOGGLE", on: e.target.checked }, refresh),
);
$("tf").addEventListener("submit", (e) => {
  e.preventDefault();
  chrome.runtime.sendMessage({ type: "TRUSTED", host: $("th").value }, (r) => {
    $("terr").textContent = r?.ok ? "" : r?.error || "";
    if (r?.ok) $("th").value = "";
    refresh();
  });
});
refresh();

const adBox = $("ads");
if (adBox)
  adBox.addEventListener("change", () =>
    chrome.runtime.sendMessage({ type: "AD_TOGGLE", on: adBox.checked }),
  );
