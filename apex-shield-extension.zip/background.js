/**
 * Apex Shield — Companion background worker.
 * Periodically checks that the Shield console is reachable and caches the
 * result for the popup. No credentials, no telemetry, no engine code —
 * the proprietary routing math never leaves the server.
 */
"use strict";

const SHIELD_ORIGIN = "https://apexsignalshield.com";
const FALLBACK_ORIGIN = "https://tinyradr.lovable.app";

async function checkShield() {
  for (const origin of [SHIELD_ORIGIN, FALLBACK_ORIGIN]) {
    try {
      const res = await fetch(`${origin}/shield.webmanifest`, {
        cache: "no-store",
        signal: AbortSignal.timeout(5000),
      });
      if (res.ok) {
        await chrome.storage.local.set({
          shieldStatus: { online: true, origin, ts: Date.now() },
        });
        return;
      }
    } catch {
      /* try next origin */
    }
  }
  await chrome.storage.local.set({
    shieldStatus: { online: false, origin: null, ts: Date.now() },
  });
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create("apex-shield-poll", { periodInMinutes: 1 });
  void checkShield();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "apex-shield-poll") void checkShield();
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "GET_STATUS") {
    chrome.storage.local.get("shieldStatus", (data) => {
      sendResponse(data.shieldStatus ?? null);
    });
    return true; // async response
  }
  if (msg?.type === "RECHECK") {
    void checkShield().then(() => sendResponse({ ok: true }));
    return true;
  }
  if (msg?.type === "OPEN_SHIELD") {
    chrome.storage.local.get("shieldStatus", (data) => {
      const origin = data.shieldStatus?.origin ?? SHIELD_ORIGIN;
      chrome.tabs.create({ url: `${origin}/shield` });
    });
  }
});
