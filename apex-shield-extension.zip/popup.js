"use strict";

function render(status) {
  const dot = document.getElementById("dot");
  const label = document.getElementById("status");
  const age = document.getElementById("age");
  if (!status) {
    dot.className = "dot offline";
    label.textContent = "unknown";
    age.textContent = "—";
    return;
  }
  dot.className = status.online ? "dot online" : "dot offline";
  label.textContent = status.online ? "online" : "offline";
  const secs = Math.round((Date.now() - status.ts) / 1000);
  age.textContent = secs < 60 ? `${secs}s ago` : `${Math.round(secs / 60)}m ago`;
}

chrome.runtime.sendMessage({ type: "GET_STATUS" }, render);

document.getElementById("open").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "OPEN_SHIELD" });
  window.close();
});

document.getElementById("recheck").addEventListener("click", () => {
  document.getElementById("status").textContent = "checking…";
  chrome.runtime.sendMessage({ type: "RECHECK" }, () => {
    chrome.runtime.sendMessage({ type: "GET_STATUS" }, render);
  });
});
