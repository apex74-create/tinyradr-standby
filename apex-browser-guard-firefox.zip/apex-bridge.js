"use strict";
// Hands an Apex Lifetime token from an Apex site page to the extension.
// The token is verified inside the extension; this script only relays it.
window.addEventListener("message", (event) => {
  if (event.source !== window || event.origin !== location.origin) return;
  const msg = event.data;
  if (
    !msg ||
    msg.source !== "apex-site" ||
    msg.type !== "APEX_LICENSE_INJECT" ||
    typeof msg.token !== "string"
  )
    return;
  chrome.runtime.sendMessage(
    { type: "APEX_LICENSE_INJECT", token: msg.token.slice(0, 2000) },
    (res) => {
      void chrome.runtime.lastError;
      window.postMessage(
        { source: "apex-guard", type: "APEX_LICENSE_RESULT", ok: Boolean(res && res.ok) },
        location.origin,
      );
    },
  );
});
window.postMessage({ source: "apex-guard", type: "APEX_GUARD_PRESENT" }, location.origin);
