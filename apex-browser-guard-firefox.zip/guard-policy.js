"use strict";
// Shared browser-safe policy. Literal URL matching does not resolve DNS.
globalThis.GuardPolicy = (() => {
  // Split by address family: RE2's compiled-memory limit is not a text-length limit.
  const PRIVATE_HOSTS = [
    "10\\.[0-9]+\\.[0-9]+\\.[0-9]+",
    "192\\.168\\.[0-9]+\\.[0-9]+",
    "172\\.(?:1[6-9]|2[0-9]|3[01])\\.[0-9]+\\.[0-9]+",
    "169\\.254\\.[0-9]+\\.[0-9]+",
    "100\\.(?:6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\\.[0-9]+\\.[0-9]+",
    "127\\.[0-9]+\\.[0-9]+\\.[0-9]+",
    "(?:0\\.0\\.0\\.0|localhost|\\[::1\\])",
    "\\[f[cd][0-9a-f:]+\\]",
    "\\[fe[89ab][0-9a-f:]+\\]",
  ];
  const resources = [
    "main_frame",
    "sub_frame",
    "xmlhttprequest",
    "script",
    "image",
    "ping",
    "websocket",
    "other",
    "media",
    "font",
    "stylesheet",
  ];
  const lanRules = PRIVATE_HOSTS.map((host, i) => ({
    id: i < 2 ? 101 + i : 102 + i,
    priority: 3,
    action: { type: "block" },
    condition: {
      regexFilter: "^(?:https?|wss?)://" + host + "(?::[0-9]+)?/",
      isUrlFilterCaseSensitive: false,
      resourceTypes: resources,
    },
  }));
  // Only trusted app initiators may reach this loopback WebSocket.
  lanRules.push({
    id: 103,
    priority: 5,
    action: { type: "allow" },
    condition: {
      regexFilter: "^ws://127\\.0\\.0\\.1(?::[0-9]+)?/",
      initiatorDomains: [
        "apexsignalshield.com",
        "tinyradr.com",
        "encryptedcb.com",
        "castnetmesh.com",
        "localhost",
        "127.0.0.1",
      ],
      resourceTypes: ["websocket"],
    },
  });
  const domain = (value) => {
    if (typeof value !== "string") return null;
    const d = value.toLowerCase();
    return d.length <= 120 && /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/.test(d)
      ? d
      : null;
  };
  const sameSite = (host, site) => host === site || host.endsWith("." + site);
  const AI_HOSTS = ["chatgpt.com", "gemini.google.com", "claude.ai"];
  const DOM_NODE_LIMIT = 20000,
    DOM_COOLDOWN_MS = 600000;
  const shouldRecover = (nodes, poorSamples) => nodes > DOM_NODE_LIMIT && poorSamples >= 2;
  // Malicious-ad shield: known ad-delivery / malvertising redirect hosts. Blocking
  // main_frame too cuts redirect chains and pop-unders that bounce through them.
  const AD_HOSTS = [
    "doubleclick.net",
    "googlesyndication.com",
    "googleadservices.com",
    "adnxs.com",
    "adsrvr.org",
    "rubiconproject.com",
    "pubmatic.com",
    "openx.net",
    "criteo.com",
    "taboola.com",
    "outbrain.com",
    "revcontent.com",
    "mgid.com",
    "propellerads.com",
    "popads.net",
    "popcash.net",
    "adcash.com",
    "exoclick.com",
    "juicyads.com",
    "trafficjunky.net",
    "hilltopads.net",
    "clickadu.com",
    "adsterra.com",
    "onclickads.net",
    "admaven.com",
    "zeropark.com",
    "richpush.co",
    "pushame.com",
    "monetag.com",
    "rollerads.com",
    "evadav.com",
    "galaksion.com",
    "pushground.com",
    "adsterratech.com",
    "highperformanceformat.com",
    "profitablecpmrate.com",
    "a-ads.com",
    "adform.net",
    "smartadserver.com",
    "yieldmo.com",
    "media.net",
    "33across.com",
    "advertising.com",
    "bidswitch.net",
    "casalemedia.com",
    "sharethrough.com",
    "teads.tv",
  ];
  const adRule = (hosts) => ({
    id: 4,
    priority: 2,
    action: { type: "block" },
    condition: {
      requestDomains: hosts,
      resourceTypes: [
        "main_frame",
        "sub_frame",
        "script",
        "xmlhttprequest",
        "image",
        "ping",
        "media",
        "other",
      ],
    },
  });
  // Lifetime tokens are verified locally with this public key. No server is
  // needed to prove ownership, now or years from now.
  const PUBLIC_JWK = {
    kty: "EC",
    crv: "P-256",
    x: "BpqBHFmxOhBWboElhQYzXEvECMaRayn0RiJdwMuZhTM",
    y: "ddtndM9BDjRheau9FVcf3UY-HVFGtESeX4oTrid_tKw",
  };
  const LICENCE_HOSTS = [
    "tinyradr.com",
    "apexsignalshield.com",
    "encryptedcb.com",
    "castnetmesh.com",
    "tinyradr.lovable.app",
    "localhost",
  ];
  const UPDATE_URL = "https://tinyradr.com/api/public/guard-update";
  const b64u = (s) =>
    Uint8Array.from(
      atob(
        s
          .replace(/-/g, "+")
          .replace(/_/g, "/")
          .padEnd(Math.ceil(s.length / 4) * 4, "="),
      ),
      (c) => c.charCodeAt(0),
    );
  async function verifyToken(token) {
    if (typeof token !== "string" || token.length > 2000) return null;
    const [body, sig, extra] = token.split(".");
    if (!body || !sig || extra !== undefined) return null;
    try {
      const subtle = globalThis.crypto.subtle;
      const key = await subtle.importKey(
        "jwk",
        PUBLIC_JWK,
        { name: "ECDSA", namedCurve: "P-256" },
        false,
        ["verify"],
      );
      const ok = await subtle.verify(
        { name: "ECDSA", hash: "SHA-256" },
        key,
        b64u(sig),
        new TextEncoder().encode(body),
      );
      if (!ok) return null;
      const payload = JSON.parse(new TextDecoder().decode(b64u(body)));
      return payload &&
        payload.iss === "apex-foundry-core" &&
        payload.prd === "apex-guard-lifetime" &&
        payload.tier === "lifetime"
        ? payload
        : null;
    } catch {
      return null;
    }
  }
  // v1.4 Link Scrub: tracking tags removed from page addresses before the request
  // leaves (Chrome's own redirect transform; the URL is never read by Guard code).
  const TRACKING_PARAMS = [
    "utm_source",
    "utm_medium",
    "utm_campaign",
    "utm_term",
    "utm_content",
    "utm_id",
    "fbclid",
    "gclid",
    "gclsrc",
    "dclid",
    "gbraid",
    "wbraid",
    "msclkid",
    "ttclid",
    "twclid",
    "li_fat_id",
    "igshid",
    "mc_cid",
    "mc_eid",
    "_hsenc",
    "_hsmi",
    "mkt_tok",
    "yclid",
    "oly_enc_id",
    "oly_anon_id",
    "vero_id",
    "rb_clickid",
    "s_cid",
  ];
  const scrubRule = {
    id: 5,
    priority: 1,
    action: {
      type: "redirect",
      redirect: { transform: { queryTransform: { removeParams: TRACKING_PARAMS } } },
    },
    condition: { resourceTypes: ["main_frame", "sub_frame"] },
  };
  // v1.4 Trusted devices: adapted from the Zapback-line local-address checker.
  // Only literal private/loopback IPv4 addresses are accepted, so a trusted entry
  // can never open a hole to the public internet.
  function trustedHost(raw) {
    if (typeof raw !== "string") return null;
    const h = raw
      .trim()
      .toLowerCase()
      .replace(/^[a-z]+:\/\//, "")
      .replace(/[/:].*$/, "");
    const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(h);
    if (!m || m.slice(1).some((o) => Number(o) > 255 || (o.length > 1 && o[0] === "0")))
      return null;
    const [a, b] = [Number(m[1]), Number(m[2])];
    const local =
      a === 10 ||
      a === 127 ||
      (a === 192 && b === 168) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 169 && b === 254) ||
      (a === 100 && b >= 64 && b <= 127);
    return local ? h : null;
  }
  const TRUSTED_BASE = 120,
    TRUSTED_MAX = 32;
  const trustedRules = (hosts) =>
    hosts
      .map(trustedHost)
      .filter(Boolean)
      .slice(0, TRUSTED_MAX)
      .map((h, i) => ({
        id: TRUSTED_BASE + i,
        priority: 6,
        action: { type: "allow" },
        condition: {
          regexFilter: "^(?:https?|wss?)://" + h.replace(/\./g, "\\.") + "(?::[0-9]+)?/",
          resourceTypes: resources,
        },
      }));
  // Versioned changelog shown in the popup. Every upgrade reaches every install.
  const CHANGELOG = [
    {
      v: "1.4.1",
      items: [
        "Threat list refresh (Oct 29, 2026) — push-notification and pop-under networks used in fake-CAPTCHA and fake-update scams",
      ],
    },
    {
      v: "1.4.0",
      items: [
        "Link Scrub — strips tracking tags (utm, fbclid, gclid…) from links you open",
        "Trusted devices — let your own router or bridge through while home-network blocking stays on",
      ],
    },
    { v: "1.3.0", items: ["Malicious-ad shield", "Lifetime unlock verified on your device"] },
  ];
  return {
    lanRules,
    resources,
    domain,
    sameSite,
    AI_HOSTS,
    DOM_NODE_LIMIT,
    DOM_COOLDOWN_MS,
    shouldRecover,
    AD_HOSTS,
    adRule,
    PUBLIC_JWK,
    UPDATE_URL,
    LICENCE_HOSTS,
    verifyToken,
    TRACKING_PARAMS,
    scrubRule,
    trustedHost,
    trustedRules,
    TRUSTED_BASE,
    TRUSTED_MAX,
    CHANGELOG,
  };
})();
