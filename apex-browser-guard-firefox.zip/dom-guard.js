"use strict";
// Opt-in only. No text, URLs, form values or DOM snapshots are collected.
(() => {
  let enabled = false,
    dirty = true,
    poor = 0,
    lastFrame = 0,
    frames = 0,
    slow = 0,
    raf = 0;
  const observer = new MutationObserver(() => {
    dirty = true;
  });
  const frame = (now) => {
    if (!enabled || document.hidden) {
      raf = 0;
      return;
    }
    if (lastFrame && now - lastFrame > 80) slow++;
    if (lastFrame) frames++;
    lastFrame = now;
    raf = requestAnimationFrame(frame);
  };
  function configure(on) {
    enabled = Boolean(on);
    observer.disconnect();
    cancelAnimationFrame(raf);
    frames = slow = poor = lastFrame = 0;
    dirty = true;
    if (enabled) {
      observer.observe(document, { childList: true, subtree: true });
      raf = requestAnimationFrame(frame);
    }
  }
  document.addEventListener("visibilitychange", () => {
    lastFrame = frames = slow = poor = 0;
    if (enabled && !document.hidden && !raf) raf = requestAnimationFrame(frame);
  });
  chrome.storage.local
    .get(["domGuard", "enabled"])
    .then((s) => configure(s.domGuard && s.enabled !== false));
  chrome.storage.onChanged.addListener((_changes, area) => {
    if (area === "local")
      chrome.storage.local
        .get(["domGuard", "enabled"])
        .then((s) => configure(s.domGuard && s.enabled !== false));
  });
  setInterval(async () => {
    if (!enabled || document.hidden) return;
    poor = frames >= 5 && slow / frames > 0.3 ? poor + 1 : 0;
    frames = slow = 0;
    if (!dirty || poor < 2) return;
    // Early exit prevents the monitor itself from exhausting a huge DOM.
    const walker = document.createTreeWalker(document, NodeFilter.SHOW_ELEMENT);
    const deadline = performance.now() + 12;
    let count = 0;
    while (walker.nextNode()) {
      count++;
      if (count > GuardPolicy.DOM_NODE_LIMIT || performance.now() > deadline) break;
    }
    if (!GuardPolicy.shouldRecover(count, poor)) return;
    dirty = false;
    try {
      const r = await chrome.runtime.sendMessage({ type: "DOM_RECOVERY" });
      if (r?.allowed && enabled && !document.hidden) location.reload();
    } catch {
      /* background unavailable: fail closed */
    }
  }, 5000);
})();
