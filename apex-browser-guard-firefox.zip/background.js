/**
 * Apex Browser Guard — local-only privacy companion.
 * Observes outgoing request headers (names only, never values), counts
 * tracker hits, and — while protection is on — strips the extra fields with
 * Chrome's own header rules. Nothing is ever sent to Apex or anyone else.
 */
"use strict";

const TRIAL_DAYS = 7;
const DAY = 86400000;

// Common tracker hosts (kept short; Chrome matches subdomains too).
const TRACKERS = [
  "facebook.net",
  "connect.facebook.net",
  "doubleclick.net",
  "google-analytics.com",
  "googletagmanager.com",
  "googlesyndication.com",
  "scorecardresearch.com",
  "hotjar.com",
  "criteo.com",
  "taboola.com",
  "outbrain.com",
  "adnxs.com",
  "amazon-adsystem.com",
  "bat.bing.com",
  "ads-twitter.com",
  "analytics.tiktok.com",
  "quantserve.com",
  "segment.io",
];

// Headers a site does not need to answer a request. Values are never read.
const EXTRA_HEADERS = [
  "sec-ch-ua-model",
  "sec-ch-ua-platform-version",
  "sec-ch-ua-full-version-list",
  "sec-ch-ua-arch",
  "sec-ch-ua-bitness",
  "sec-ch-ua-wow64",
  "x-client-data",
];

const STRIP_RULES = [
  {
    id: 1,
    priority: 1,
    action: {
      type: "modifyHeaders",
      requestHeaders: EXTRA_HEADERS.map((h) => ({ header: h, operation: "remove" })),
    },
    condition: {
      resourceTypes: [
        "main_frame",
        "sub_frame",
        "xmlhttprequest",
        "script",
        "image",
        "ping",
        "other",
      ],
    },
  },
  {
    id: 2,
    priority: 1,
    action: {
      type: "modifyHeaders",
      requestHeaders: [
        { header: "cookie", operation: "remove" },
        { header: "referer", operation: "remove" },
      ],
    },
    condition: {
      domainType: "thirdParty",
      resourceTypes: ["sub_frame", "xmlhttprequest", "script", "image", "ping", "other"],
    },
  },
  {
    id: 3,
    priority: 2,
    action: { type: "block" },
    condition: {
      requestDomains: TRACKERS,
      resourceTypes: ["script", "image", "xmlhttprequest", "ping", "sub_frame", "other"],
    },
  },
];

// Literal-host LAN shield, not resolved-IP or DNS-rebinding protection.
const LAN_RULES = GuardPolicy.lanRules;
const LAN_RULE_IDS = LAN_RULES.map((r) => r.id);
const MAX_SITES = 128,
  MAX_HOSTS = 64;
const own = (obj, key) => Object.prototype.hasOwnProperty.call(obj, key);
const retain = (obj, limit) => Object.fromEntries(Object.entries(obj).slice(-limit));

// User-blocked domains get dynamic rules from id 1000 up.
const USER_RULE_BASE = 1000;

async function getState() {
  const s = await chrome.storage.local.get(["installedAt", "unlocked", "log"]);
  if (!s.installedAt) {
    s.installedAt = Date.now();
    await chrome.storage.local.set({ installedAt: s.installedAt });
  }
  const trialLeft = Math.max(0, TRIAL_DAYS - Math.floor((Date.now() - s.installedAt) / DAY));
  return { ...s, trialLeft, protecting: Boolean(s.unlocked) || trialLeft > 0, log: s.log ?? {} };
}

// Serialize startup, alarms and popup changes to avoid duplicate-ID races.
let ruleUpdate = Promise.resolve();
function applyRules() {
  ruleUpdate = ruleUpdate.then(updateRules, updateRules);
  return ruleUpdate;
}

async function updateRules() {
  const st = await getState();
  const {
    enabled = true,
    lanShield = true,
    blockedDomains = [],
    allowedDomains = [],
  } = await chrome.storage.local.get(["enabled", "lanShield", "blockedDomains", "allowedDomains"]);
  const on = st.protecting && enabled;
  const blocked = [...new Set(blockedDomains.map(GuardPolicy.domain).filter(Boolean))].slice(
    0,
    128,
  );
  const allowed = allowedDomains.map(GuardPolicy.domain).filter(Boolean);
  const userRules = blocked.map((d, i) => ({
    id: USER_RULE_BASE + i,
    priority: 4,
    action: { type: "block" },
    condition: { requestDomains: [d], resourceTypes: GuardPolicy.resources },
  }));
  const { adShield = true, adHosts = [] } = await chrome.storage.local.get(["adShield", "adHosts"]);
  const extraAds = adHosts.map(GuardPolicy.domain).filter(Boolean).slice(0, 500);
  const ads = GuardPolicy.adRule(
    [...new Set([...GuardPolicy.AD_HOSTS, ...extraAds])].filter((d) => !allowed.includes(d)),
  );
  const { linkScrub = true, trustedHosts = [] } = await chrome.storage.local.get([
    "linkScrub",
    "trustedHosts",
  ]);
  const trusted = GuardPolicy.trustedRules(trustedHosts);
  const strip = STRIP_RULES.map((r) =>
    r.id === 3 && allowed.length
      ? { ...r, condition: { ...r.condition, excludedRequestDomains: allowed } }
      : r,
  );
  try {
    const existing = await chrome.declarativeNetRequest.getDynamicRules();
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: existing.filter((r) => r.id <= 200 || r.id >= USER_RULE_BASE).map((r) => r.id),
      addRules: [
        ...(on ? strip : []),
        ...(on && adShield ? [ads] : []),
        ...(enabled && linkScrub ? [GuardPolicy.scrubRule] : []),
        ...(enabled && lanShield ? [...LAN_RULES, ...trusted] : []),
        ...(enabled ? userRules : []),
      ],
    });
    await chrome.storage.local.set({ ruleStatus: "configured-literal-hosts", ruleError: null });
    return on;
  } catch (e) {
    await chrome.storage.local.set({
      ruleStatus: "error",
      ruleError: String(e.message || e).slice(0, 300),
    });
    return false;
  }
}

// Per-site counters, kept for 24 hours only.
let pending = Object.create(null);
let flushTimer = null;
function bump(site, field, n = 1) {
  if (!own(pending, site) && Object.keys(pending).length >= MAX_SITES) return;
  const row = (pending[site] ??= { seen: {}, removed: 0, trackers: 0 });
  if (field === "removed") row.removed += n;
  else if (field === "trackers") row.trackers += n;
  else row.seen[field] = (row.seen[field] ?? 0) + n;
  if (!flushTimer) flushTimer = setTimeout(flush, 1500);
}
async function flush() {
  flushTimer = null;
  const batch = pending;
  pending = Object.create(null);
  const hostBatch = pendingHosts;
  pendingHosts = Object.create(null);
  const {
    log = {},
    logDay = 0,
    hosts = {},
  } = await chrome.storage.local.get(["log", "logDay", "hosts"]);
  const rollover = Date.now() - logDay > DAY;
  const fresh = rollover ? {} : Object.assign(Object.create(null), log);
  for (const [site, row] of Object.entries(batch)) {
    const cur = (fresh[site] ??= { seen: {}, removed: 0, trackers: 0 });
    for (const [k, v] of Object.entries(row.seen)) cur.seen[k] = (cur.seen[k] ?? 0) + v;
    cur.removed += row.removed;
    cur.trackers += row.trackers;
  }
  const freshHosts = rollover ? {} : Object.assign(Object.create(null), hosts);
  for (const [site, row] of Object.entries(hostBatch)) {
    const cur = (freshHosts[site] ??= Object.create(null));
    for (const [h, n] of Object.entries(row)) cur[h] = (cur[h] ?? 0) + n;
  }
  for (const site of Object.keys(freshHosts))
    freshHosts[site] = retain(freshHosts[site], MAX_HOSTS);
  await chrome.storage.local.set({
    log: retain(fresh, MAX_SITES),
    hosts: retain(freshHosts, MAX_SITES),
    logDay: rollover ? Date.now() : logDay,
  });
}

function siteOf(details) {
  try {
    return new URL(details.initiator || details.documentUrl || details.url).hostname;
  } catch {
    return "unknown";
  }
}

// Third-party hosts each site talks to, kept 24h for the unknown-domain panel.
let pendingHosts = Object.create(null);
function bumpHost(site, host) {
  if (!own(pendingHosts, site) && Object.keys(pendingHosts).length >= MAX_SITES) return;
  const row = (pendingHosts[site] ??= Object.create(null));
  if (!own(row, host) && Object.keys(row).length >= MAX_HOSTS) return;
  row[host] = (pendingHosts[site]?.[host] ?? 0) + 1;
  if (!flushTimer) flushTimer = setTimeout(flush, 1500);
}

chrome.webRequest.onSendHeaders.addListener(
  (details) => {
    if (details.incognito) return;
    const site = siteOf(details);
    let host = "";
    try {
      host = new URL(details.url).hostname;
    } catch {
      /* ignore */
    }
    const thirdParty = host && site !== "unknown" && !GuardPolicy.sameSite(host, site);
    if (thirdParty) bumpHost(site, host);
    for (const h of details.requestHeaders ?? []) {
      const name = h.name.toLowerCase();
      if (EXTRA_HEADERS.includes(name)) bump(site, name);
      if (thirdParty && (name === "cookie" || name === "referer"))
        bump(site, `third-party ${name}`);
    }
  },
  { urls: ["<all_urls>"] },
  ["requestHeaders"],
);

chrome.webRequest.onErrorOccurred.addListener(
  (d) => {
    if (d.incognito) return; /* Unattributed network failures are not tracker evidence. */
  },
  { urls: ["<all_urls>"] },
);

// Lifetime token: verified locally, stored forever. No phone-home is needed.
async function acceptToken(token) {
  const payload = await GuardPolicy.verifyToken(token);
  if (!payload) return false;
  await chrome.storage.local.set({
    unlocked: true,
    tier: "lifetime",
    licenceToken: token,
    licenceIssuedAt: payload.iat ?? null,
  });
  await applyRules();
  return true;
}

// Daily update check. If the server is gone or offline, nothing changes:
// the saved blocklist and the local licence keep working.
async function checkUpdates() {
  const { lastUpdateCheck = 0 } = await chrome.storage.local.get(["lastUpdateCheck"]);
  if (Date.now() - lastUpdateCheck < DAY) return;
  await chrome.storage.local.set({ lastUpdateCheck: Date.now() });
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 8000);
    const res = await fetch(GuardPolicy.UPDATE_URL, {
      signal: ctrl.signal,
      credentials: "omit",
      cache: "no-store",
    });
    clearTimeout(t);
    if (!res.ok) return;
    const data = await res.json();
    const hosts = Array.isArray(data?.adHosts)
      ? data.adHosts.map(GuardPolicy.domain).filter(Boolean).slice(0, 500)
      : null;
    if (hosts) {
      await chrome.storage.local.set({
        adHosts: hosts,
        adListVersion: String(data.version ?? "").slice(0, 40),
      });
      await applyRules();
    }
  } catch {
    /* offline or server unreachable: keep working as-is */
  }
}

chrome.runtime.onInstalled.addListener((details) => {
  if (details?.reason === "update" && details.previousVersion)
    void chrome.storage.local.set({ previousVersion: details.previousVersion });
  chrome.alarms.create("guard-daily", { periodInMinutes: 60 });
  void applyRules();
  void checkUpdates();
});
chrome.runtime.onStartup.addListener(() => {
  void applyRules();
  void checkUpdates();
});
chrome.alarms.onAlarm.addListener(() => {
  void applyRules();
  void checkUpdates();
});

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (sender.id !== chrome.runtime.id) return false;
  const popup = sender.url === chrome.runtime.getURL("popup.html");
  if (!popup && msg?.type !== "DOM_RECOVERY" && msg?.type !== "APEX_LICENSE_INJECT") return false;
  (async () => {
    if (msg?.type === "APEX_LICENSE_INJECT") {
      let host = "";
      try {
        host = new URL(sender.url).hostname;
      } catch {
        /* ignore */
      }
      if (!GuardPolicy.LICENCE_HOSTS.some((h) => GuardPolicy.sameSite(host, h))) {
        reply({ ok: false });
        return;
      }
      reply({ ok: await acceptToken(msg.token) });
    } else if (msg?.type === "LINK_TOGGLE") {
      await chrome.storage.local.set({ linkScrub: Boolean(msg.on) });
      await applyRules();
      reply({ linkScrub: Boolean(msg.on) });
    } else if (msg?.type === "TRUSTED") {
      const h = GuardPolicy.trustedHost(msg.host);
      if (!h) {
        reply({ ok: false, error: "Private or loopback IPv4 only, e.g. 192.168.1.1" });
        return;
      }
      const { trustedHosts = [] } = await chrome.storage.local.get("trustedHosts");
      const list = new Set(trustedHosts);
      msg.remove ? list.delete(h) : list.add(h);
      if (list.size > GuardPolicy.TRUSTED_MAX) {
        reply({ ok: false, error: "Trusted device limit reached" });
        return;
      }
      await chrome.storage.local.set({ trustedHosts: [...list] });
      await applyRules();
      reply({ ok: true });
    } else if (msg?.type === "AD_TOGGLE") {
      await chrome.storage.local.set({ adShield: Boolean(msg.on) });
      await applyRules();
      reply({ adShield: Boolean(msg.on) });
    } else if (msg?.type === "DOM_RECOVERY") {
      let host;
      try {
        host = new URL(sender.url).hostname;
      } catch {
        reply({ allowed: false });
        return;
      }
      if (!GuardPolicy.AI_HOSTS.includes(host) || sender.tab?.incognito) {
        reply({ allowed: false });
        return;
      }
      const {
        domGuard = false,
        enabled = true,
        domRecovery = {},
      } = await chrome.storage.local.get(["domGuard", "enabled", "domRecovery"]);
      const key = `${sender.tab?.id}:${sender.frameId}:${host}`;
      const allowed = Boolean(
        domGuard && enabled && Date.now() - (domRecovery[key] || 0) >= GuardPolicy.DOM_COOLDOWN_MS,
      );
      if (allowed)
        await chrome.storage.local.set({
          domRecovery: retain({ ...domRecovery, [key]: Date.now() }, 128),
        });
      reply({ allowed });
    } else if (msg?.type === "DOM_TOGGLE") {
      await chrome.storage.local.set({ domGuard: Boolean(msg.on) });
      reply({ ok: true });
    } else if (msg?.type === "STATE") {
      await flush();
      const st = await getState();
      const {
        enabled = true,
        lanShield = true,
        hosts = {},
        blockedDomains = [],
        allowedDomains = [],
        domGuard = false,
        ruleStatus = "pending",
        ruleError = null,
        adShield = true,
        tier = null,
        linkScrub = true,
        trustedHosts = [],
        previousVersion = null,
      } = await chrome.storage.local.get([
        "enabled",
        "lanShield",
        "hosts",
        "blockedDomains",
        "allowedDomains",
        "domGuard",
        "ruleStatus",
        "ruleError",
        "adShield",
        "tier",
        "linkScrub",
        "trustedHosts",
        "previousVersion",
      ]);
      reply({
        ...st,
        linkScrub,
        trustedHosts,
        previousVersion,
        version: chrome.runtime.getManifest().version,
        domGuard,
        adShield,
        tier,
        ruleStatus,
        ruleError,
        enabled,
        lanShield,
        hosts,
        blockedDomains,
        allowedDomains,
        active: st.protecting && enabled && ruleStatus !== "error",
        incognitoAllowed: await chrome.extension.isAllowedIncognitoAccess(),
      });
    } else if (msg?.type === "TOGGLE") {
      await chrome.storage.local.set({ enabled: Boolean(msg.on) });
      reply({ active: await applyRules() });
    } else if (msg?.type === "LAN_TOGGLE") {
      await chrome.storage.local.set({ lanShield: Boolean(msg.on) });
      await applyRules();
      reply({ lanShield: Boolean(msg.on) });
    } else if (msg?.type === "DOMAIN_BLOCK" || msg?.type === "DOMAIN_ALLOW") {
      const d = GuardPolicy.domain(msg.domain);
      if (!d) {
        reply({ ok: false, error: "Invalid domain" });
        return;
      }
      const key = msg.type === "DOMAIN_BLOCK" ? "blockedDomains" : "allowedDomains";
      const other = msg.type === "DOMAIN_BLOCK" ? "allowedDomains" : "blockedDomains";
      const cur = await chrome.storage.local.get([key, other]);
      const list = new Set(cur[key] ?? []);
      msg.remove ? list.delete(d) : list.add(d);
      if (list.size > 128) {
        reply({ ok: false, error: "Domain limit reached" });
        return;
      }
      const otherList = (cur[other] ?? []).filter((x) => x !== d);
      await chrome.storage.local.set({ [key]: [...list], [other]: otherList });
      await applyRules();
      reply({ ok: true });
    } else if (msg?.type === "CLEAR") {
      pending = Object.create(null);
      pendingHosts = Object.create(null);
      await chrome.storage.local.set({ log: {}, hosts: {}, logDay: Date.now() });
      reply({ ok: true });
    } else if (msg?.type === "SEARCH") {
      const url = `https://lite.duckduckgo.com/lite/?q=${encodeURIComponent(String(msg.q).slice(0, 300))}`;
      const allowed = await chrome.extension.isAllowedIncognitoAccess();
      if (allowed) chrome.windows.create({ url, incognito: true });
      else chrome.tabs.create({ url });
      reply({ incognito: allowed });
    }
  })().catch((e) => reply({ ok: false, error: String(e.message || e).slice(0, 300) }));
  return true;
});
